﻿Accounting Excel is a MS Excel VbA software for the purpose of financial accounting. It is free open source software awarded as Rising Star Software by sourceforge.net. To any person obtaining a copy and associated documentation files (the "Accounts26.zip").Users can use this software as much as they want. But they can't modify it and publish it under their own name. Costing and COGS, received and payment details cheque no,RTGS,NEFT,Online banking, offline banking, debit credit card, crypto currency etc details is to be provided in voucher  these are included. Generation of bank book for bank reconcilation also included. Customers and Suppliers Ledger are included. 										
First change windows system date in dd-mm-yyyy format ( control panel --> clock language and region, additional setting
, date format dd-mm-yyyy.									
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE						
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE												
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TO OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.												
[2024] [ Nyarko Philip Abel ]								
email  aphilipnyarko@gmail.com	
                                                                      PROCEDURE

First create  company profile by  clicking Create Company/Profile Setting Menu, click on view, do necessary correction and click on update.  Then click on voucher  menu to input all vouchers. User can update,correct,delete , create and print  vouchers .See the guide line below to input voucher data.  After entering  all vouchers click on Account Master Menu for update,correct,delete , create account master data . See the guide line below Account Master And Account Code.  After  updating account master data Click on Generate Periodical Financial Data. This menu will generate all transaction data from vouchers for a specific period and vouchers should be within the mentioned period which is specified in this menu. Then click on journal,  cashbook,  bankbook, general ledger, trial balance, balance sheet and profit and loss account menu option to get desired out put. After doing all these options on the first day of next month users have to convert current account master balances to monthly opening balances and then to run convert monthly closing balance to next month opening balance.
							
Account Master And Account Code								
Depending upon the principal of basic accounting normaly the account heads leading to assets starts with 1, liabilities’ with 2, equity with 3 Revenues, sales, commission and other incomes with 4 and 5, expenses with 6. All are 6 digits account code. In the Account Master option you will get stop to modify the debit/credit, assets/liabilities, income/expenses code stated in their respective form. You can add, modify	 delete account codes along with view and reset form. Do reset after every operation in any input form.									
Voucher Preparation										
The user must have basic accounting knowledge to use this software. In voucher page there are options for new voucher, correction, delete and print. In a voucher you have to specify first the voucher type at the top drop down menu. For sales and purchase there are customers and suppliers masters. From drop down you have to select the customer or supplier's name and automatically their respective code no will be displayed automatically. Voucher number is automatic don't do anything there. Now input sales or purchase reference or invoice or bill no and reference date or invoice or bill date.  Similarly input voucher date. Now in below the Account Description just select account Description from dropdown and the account code number will be automatically displayed, now input Debit and Credit amount.	
For any conjugated voucher entry you have to bifurcate the records of transaction as exampled below.												
For a sales voucher if 12000 is total sales and among this amount 8000 is cash and 4000 is in credit then the voucher entry should be												
A/C Code	A/C Description	Dr. Amount	Cr. Amount	Mode	Debit / Credit Notes, Sales Return/ Purchase Return				Separate Option in Main Menu			
100002	Cash at Bank	8000	0	Bank	A/C Code	A/C Description	Dr. Amount	Cr. Amount	Mode			
400004	Sales	0	8000	Bank	100002	Cash at Bank	6000		Bank			
100012	Accounts Receivable	4000		Credit	601106	Purchase Return		6000	Bank			
400004	Sales		4000	Credit	100002	Cash at Bank	1000		Bank			
					600172	Output CGST		1000	Bank			
Debtors and Creditors Master												
Option is given in main menu for creating, updating deleting customer, suppliers master records.												
Always click on Reset Option after every operation. For any new add in master, just type or fillip or input the form and then click on Add.												
You can navigate from one record to another record, view any particular company information by View option. You can delete any master.												
												
Processing 												
This software operates the account statements and transaction data for a period preferably on monthly basis. After closing of a month opt												
Transfer current closing balance to next month opening balance. For example if January 2022 month's account is closed then transfer the												
closing balance of January 2022 to the opening balance of February 2022 and simultaneously opt for Generate Periodical Financial Transaction												
Data, for monthly basis and then run the statements of cash book, journal, ledger, sub ledger, trial balance, balance sheet and profit and loss												
Statements. Monthly opening balance will be stored on MlyOpBal worksheet and there is option to fetch the opening balance of any month as												
opening balance and generate the financial data for that particular month and re calculate and state the cash book, journal, general ledger, Trial balance, balance sheet, balance sheet for reference, profit and loss statement.												
Debtors and Creditors Transaction and Ledger
Run Debtors creditors transaction option and then click to Debtors for debtors record cumulative and click on Creditors option for same of Creditors.												
Bank Reconcilation Statement Menu is added which is self explanatory										
In order to reconcile a bank statement, you need to evaluate financial records with bank statements. 										
In the case of bank errors, undeducted for deposits, and unused checks, adjust the balance on the bank statement.										
Deposit Understate: Cheques that have not been presented in a bank are referred to as deposit understated.										
A deposit in transit is money that has been received by a company and recorded in the company's										
accounting system. The deposit has already been sent to the bank, but it has yet to be processed										
and posted to the bank account.										
Error in Bank: The amount that the bank incorrectly recorded in the company’s statement.